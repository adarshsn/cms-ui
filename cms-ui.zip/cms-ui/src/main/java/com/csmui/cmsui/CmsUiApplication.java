package com.csmui.cmsui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmsUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmsUiApplication.class, args);
	}

}

